CREATE VIEW view_articles AS
  SELECT
    `news`.`article`.`IDARTICLE`            AS `IDARTICLE`,
    `news`.`article`.`IDAUTEUR`             AS `IDAUTEUR`,
    `news`.`article`.`IDCATEGORIE`          AS `IDCATEGORIE`,
    `news`.`categorie`.`LIBELLECATEGORIE`   AS `LIBELLECATEGORIE`,
    `news`.`article`.`TITREARTICLE`         AS `TITREARTICLE`,
    `news`.`article`.`CONTENUARTICLE`       AS `CONTENUARTICLE`,
    `news`.`article`.`FEATUREDIMAGEARTICLE` AS `FEATUREDIMAGEARTICLE`,
    `news`.`article`.`SPECIALARTICLE`       AS `SPECIALARTICLE`,
    `news`.`article`.`SPOTLIGHTARTICLE`     AS `SPOTLIGHTARTICLE`,
    `news`.`article`.`DATECREATIONARTICLE`  AS `DATECREATIONARTICLE`,
    `news`.`auteur`.`NOMAUTEUR`             AS `NOMAUTEUR`,
    `news`.`auteur`.`PRENOMAUTEUR`          AS `PRENOMAUTEUR`,
    `news`.`auteur`.`EMAILAUTEUR`           AS `EMAILAUTEUR`
  FROM ((`news`.`article`
    JOIN `news`.`auteur`) JOIN `news`.`categorie`)
  WHERE ((`news`.`article`.`IDAUTEUR` = `news`.`auteur`.`IDAUTEUR`) AND
         (`news`.`article`.`IDCATEGORIE` = `news`.`categorie`.`IDCATEGORIE`));

